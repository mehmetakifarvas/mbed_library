#include "mbed.h"
#include "TextLCD.h"
#include "Keypad.h"
#include <iostream>
#include "MFRC522.h"

Serial pc(USBTX,USBRX);
//KL25Z Pins for MFRC522 SPI interface
#define SPI_MOSI    PA_7 //Master output slave input
#define SPI_MISO    PA_6  //Master input slave Output
#define SPI_SCLK    PA_5 //SCK Clock pulse saat darbesi
#define SPI_CS      PB_6 //SDA data pini
// KL25Z Pin for MFRC522 reset
#define MF_RESET    PC_7 //RST

MFRC522  RfChip(SPI_MOSI, SPI_MISO, SPI_SCLK, SPI_CS, MF_RESET);
DigitalOut bzr(PB_7);
DigitalOut role(PA_5);
char sifre[4];
uint8_t sayac=0;
uint8_t hata=3;
char basilantus;
TextLCD lcd(PB_0,PA_4,PC_3,PC_2,PB_3,PA_10);
Keypad key(PC_12, PC_10, PC_11,PD_2,PA_13,PA_14,PA_15,PC_8);
char key_table[] = {
    '1', '2', '3', 'A',
    '4', '5', '6', 'B',
    '7', '8', '9', 'C',
    '*', '0', '#', 'D'
};

void hatametodu()
{

    lcd.cls();
    bzr=0;
    role=0;
    lcd.printf("Giris basarisiz");
    for(uint8_t x=0; x<20; x++) {
        bzr=1;
        wait_ms(50);
        bzr=0;
        wait_ms(10);
    }
    hata--;
    if(hata==0) {
        lcd.cls();
        hata=3;
        for(uint8_t sure=10; sure>0; sure--) {
            lcd.locate(0,0);
            lcd.printf("%d",sure);
            lcd.printf(" ");
            wait(1);
        }

    }
    lcd.cls();
}

int main()
{
    pc.baud(115200);
    // Init. RC522 Chip
    RfChip.PCD_Init();
    uint32_t key_num;
    while(true) {

        while ((key_num = key.read()) != 0) {
            bzr=1;
            wait_ms(10);
            bzr=0;
            sifre[sayac]=*(key_table + key_num-1);
            sayac++;
            lcd.printf("*");
            cout<<*(key_table + key_num-1)<<endl;
            if(sayac==4) {
                sayac=0;
                if(sifre[0]=='1' && sifre[1]=='2' && sifre[2]=='3' && sifre[3]=='A') {
                    role=1;
                    hata=3;
                    lcd.cls();
                    lcd.printf("Giris basarili");
                    wait(3);
                    role=0;
                    lcd.cls();
                } else {
                    hatametodu();
                }
                lcd.cls();
            }//if(sayac==4) {

        }//   while ((key_num = key.read()) != 0) {

        // Look for new cards
        if (!RfChip.PICC_IsNewCardPresent()) {
            wait_ms(10);
            continue;
        }



        // Select one of the cards
        if ( ! RfChip.PICC_ReadCardSerial()) {
            wait_ms(10);
            continue;
        }

        // Print Card UID
        printf("Kart ID: ");
        for (uint8_t i = 0; i < RfChip.uid.size; i++) {
            pc.printf(" %X", RfChip.uid.uidByte[i]);
        }
        pc.printf("\n");

//kendi kartınızı id'si olacak
        if(RfChip.uid.uidByte[0]==0x76 && RfChip.uid.uidByte[1]==0x45 && RfChip.uid.uidByte[2]==0x55 && RfChip.uid.uidByte[3]==0xF5) {
            hata=3;
            bzr=1;
            lcd.cls();
            lcd.printf("Hosgeldiniz Ayse");
            wait(2);
            bzr=0;
            lcd.cls();
        } else {
            hatametodu();
        }


        // Print Card type
        uint8_t piccType = RfChip.PICC_GetType(RfChip.uid.sak);
        pc.printf("PICC Type: %s \n\r", RfChip.PICC_GetTypeName(piccType));

    }//  while(true) {

 
}//main